# Campus Club Connect — MP3 Submission Notes

## Published JSON URL

`https://raw.githubusercontent.com/ardonreyes/MOB-DEV-2/main/CampusCompanion/clubs.json`

The app is already configured to use this URL. Commit and push `CampusCompanion/clubs.json` to the repository's `main` branch before taking the final network-sync screenshot. Until it is published, the app intentionally loads the bundled copy so the club directory remains usable.

## Screenshot Checklist

1. Open **Browse Campus Clubs** after publishing the JSON and capture the five synchronized club rows.
2. Choose a profile photo, capture the welcome screen, terminate the app, relaunch it, and capture the restored photo.
3. Set a simulated location, open **Campus Map**, grant When In Use access, and capture the campus pin and meter-distance label.

## Reflection

URLSession and Codable fill roles similar to Retrofit and Gson, but iOS exposes the request, HTTP-response validation, decoding, and thread hop more explicitly in this completion-handler workflow. PHPickerViewController and the Android Photo Picker both provide privacy-respecting access only to the image selected by the user, while FileManager stores the resulting file inside the app's sandbox. CLLocationManager resembles FusedLocationProviderClient because both require runtime authorization and return asynchronous location updates. MapKit integrates the map and annotations directly with UIKit, while CLLocation.distance(from:) provides the same kind of meter-based calculation as Android's Location.distanceTo().
