import UIKit
import CoreData

final class AnnouncementsViewController: UITableViewController {
    private let clubService = ClubService()
    private var clubs: [PersistentClub] = []
    private var isSyncing = false

    private var context: NSManagedObjectContext {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            fatalError("AppDelegate is unavailable")
        }
        return appDelegate.persistentContainer.viewContext
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Campus Clubs"
        configureTableView()
        configureMoreMenu()
        loadClubs()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        syncClubs()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        navigationController?.interactivePopGestureRecognizer?.isEnabled = true
    }

    private func configureTableView() {
        tableView.register(ClubCell.self, forCellReuseIdentifier: "ClubCell")
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 72

        refreshControl = UIRefreshControl()
        refreshControl?.accessibilityLabel = "Refresh campus clubs"
        refreshControl?.addTarget(
            self,
            action: #selector(refreshClubs),
            for: .valueChanged
        )
    }

    /// Keeps the existing hamburger button while exposing both required MP3 routes.
    private func configureMoreMenu() {
        let refreshAction = UIAction(
            title: "Refresh Clubs",
            image: UIImage(systemName: "arrow.clockwise")
        ) { [weak self] _ in
            self?.syncClubs()
        }

        let campusMapAction = UIAction(
            title: "Campus Map",
            image: UIImage(systemName: "map.fill")
        ) { [weak self] _ in
            self?.performSegue(
                withIdentifier: "ShowAnnouncementDetailSegue",
                sender: nil
            )
        }

        let menu = UIMenu(children: [refreshAction, campusMapAction])
        let moreButton = UIBarButtonItem(
            image: UIImage(systemName: "line.3.horizontal"),
            menu: menu
        )
        moreButton.accessibilityLabel = "More actions"
        navigationItem.rightBarButtonItem = moreButton
    }

    @objc private func refreshClubs() {
        syncClubs()
    }

    private func syncClubs() {
        guard !isSyncing else { return }

        isSyncing = true

        clubService.fetchClubs { [weak self] result in
            DispatchQueue.main.async {
                guard let self else { return }

                defer {
                    self.isSyncing = false
                    self.refreshControl?.endRefreshing()
                }

                switch result {
                case .success(let clubDTOs):
                    self.replaceClubs(with: clubDTOs)
                case .failure(let error):
                    print("Using bundled clubs after sync failure: \(error.localizedDescription)")
                    if self.clubs.isEmpty {
                        self.loadBundledClubs()
                    }
                }
            }
        }
    }

    /// The bundled copy provides useful first-run data until clubs.json is published.
    private func loadBundledClubs() {
        guard let fileURL = Bundle.main.url(
            forResource: "clubs",
            withExtension: "json"
        ) else {
            print("Bundled clubs.json was not found.")
            return
        }

        do {
            let data = try Data(contentsOf: fileURL)
            let clubDTOs = try JSONDecoder().decode([ClubDTO].self, from: data)
            replaceClubs(with: clubDTOs)
        } catch {
            print("Could not decode bundled clubs: \(error.localizedDescription)")
        }
    }

    /// Delete-then-insert keeps Core Data identical to the remote source of truth.
    private func replaceClubs(with clubDTOs: [ClubDTO]) {
        do {
            let existingClubs = try context.fetch(PersistentClub.fetchRequest())
            existingClubs.forEach(context.delete)

            for dto in clubDTOs {
                let club = PersistentClub(context: context)
                club.name = dto.name
                club.category = dto.category
                club.iconName = dto.iconName
            }

            try context.save()
            loadClubs()
        } catch {
            context.rollback()
            print("Could not synchronize clubs in Core Data: \(error.localizedDescription)")
        }
    }

    private func loadClubs() {
        let request = PersistentClub.fetchRequest()
        request.sortDescriptors = [
            NSSortDescriptor(key: "name", ascending: true)
        ]

        do {
            clubs = try context.fetch(request)
            tableView.reloadData()

            if clubs.isEmpty {
                let emptyLabel = UILabel()
                emptyLabel.text = "Refreshing campus clubs…"
                emptyLabel.textAlignment = .center
                emptyLabel.textColor = .secondaryLabel
                tableView.backgroundView = emptyLabel
            } else {
                tableView.backgroundView = nil
            }
        } catch {
            print("Could not load saved clubs: \(error.localizedDescription)")
        }
    }

    override func tableView(
        _ tableView: UITableView,
        numberOfRowsInSection section: Int
    ) -> Int {
        clubs.count
    }

    override func tableView(
        _ tableView: UITableView,
        cellForRowAt indexPath: IndexPath
    ) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(
            withIdentifier: "ClubCell",
            for: indexPath
        ) as? ClubCell else {
            return UITableViewCell()
        }

        cell.configure(with: clubs[indexPath.row])
        cell.accessoryType = .disclosureIndicator
        return cell
    }

    override func tableView(
        _ tableView: UITableView,
        didSelectRowAt indexPath: IndexPath
    ) {
        tableView.deselectRow(at: indexPath, animated: true)

        let club = clubs[indexPath.row]
        let alert = UIAlertController(
            title: club.name,
            message: "Category: \(club.category)",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "Close", style: .default))
        present(alert, animated: true)
    }
}
