import UIKit
import MapKit
import CoreLocation

final class DetailViewController: UIViewController, CLLocationManagerDelegate {
    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var campusMapView: MKMapView!
    @IBOutlet weak var distanceLabel: UILabel!

    var studentName: String = ""
    var notificationsEnabled: Bool = false
    var selectedRole: String = ""
    var eventDate: Date = Date()
    var guestCount: Int = 1
    var announcement: CampusAnnouncement?

    private enum CampusLocation {
        static let coordinate = CLLocationCoordinate2D(
            latitude: 14.6255,
            longitude: 121.0034
        )
    }

    private enum LibraryLocation {
        static let coordinate = CLLocationCoordinate2D(
            latitude: 14.6264,
            longitude: 121.0042
        )
    }

    private let locationManager = CLLocationManager()

    override func viewDidLoad() {
        super.viewDidLoad()

        messageLabel.textAlignment = .center
        messageLabel.numberOfLines = 0
        distanceLabel.textAlignment = .center
        distanceLabel.numberOfLines = 0

        configureCampusMap()
        configureLocationUpdates()
        configureMessage()
    }

    private func configureCampusMap() {
        let region = MKCoordinateRegion(
            center: CampusLocation.coordinate,
            latitudinalMeters: 500,
            longitudinalMeters: 500
        )
        campusMapView.setRegion(region, animated: false)

        let campusAnnotation = MKPointAnnotation()
        campusAnnotation.coordinate = CampusLocation.coordinate
        campusAnnotation.title = "FEU Tech Campus"
        campusMapView.addAnnotation(campusAnnotation)

        let libraryAnnotation = MKPointAnnotation()
        libraryAnnotation.coordinate = LibraryLocation.coordinate
        libraryAnnotation.title = "Campus Library"
        campusMapView.addAnnotation(libraryAnnotation)
    }

    private func configureLocationUpdates() {
        locationManager.delegate = self
        distanceLabel.text = "Waiting for location permission..."

        switch locationManager.authorizationStatus {
        case .authorizedWhenInUse, .authorizedAlways:
            locationManager.requestLocation()
        case .denied, .restricted:
            distanceLabel.text = "Location access denied."
        case .notDetermined:
            locationManager.requestWhenInUseAuthorization()
        @unknown default:
            distanceLabel.text = "Location status unavailable."
        }
    }

    private func configureMessage() {
        if let announcement {
            title = announcement.category
            messageLabel.text = [
                announcement.title,
                announcement.date,
                "Category: " + announcement.category,
                "Location: " + announcement.location,
                "Priority Level: " + announcement.priorityLevel,
                "Posted by: " + announcement.postedBy
            ].joined(separator: "\n")
            return
        }

        title = "Campus Map"

        if studentName.isEmpty {
            messageLabel.text = "Campus Club Connect\nFEU Tech Campus"
            return
        }

        let notificationStatus = notificationsEnabled ? "on" : "off"
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .none

        messageLabel.text = [
            "Welcome, " + studentName + "!",
            "(" + selectedRole + ")",
            "Notifications: " + notificationStatus + ".",
            "Event date: " + dateFormatter.string(from: eventDate),
            "Guests: " + String(guestCount)
        ].joined(separator: "\n")
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        switch manager.authorizationStatus {
        case .authorizedWhenInUse, .authorizedAlways:
            manager.requestLocation()
        case .denied, .restricted:
            distanceLabel.text = "Location access denied."
        case .notDetermined:
            break
        @unknown default:
            distanceLabel.text = "Location status unavailable."
        }
    }

    func locationManager(
        _ manager: CLLocationManager,
        didUpdateLocations locations: [CLLocation]
    ) {
        guard let currentLocation = locations.first else {
            return
        }

        let campusLocation = CLLocation(
            latitude: CampusLocation.coordinate.latitude,
            longitude: CampusLocation.coordinate.longitude
        )
        let distanceInMeters = currentLocation.distance(from: campusLocation)

        distanceLabel.text = String(
            format: "You are approximately %.0f meters from campus.",
            distanceInMeters
        )
    }

    func locationManager(
        _ manager: CLLocationManager,
        didFailWithError error: Error
    ) {
        distanceLabel.text = "Unable to determine your distance from campus."
        print("Location error: " + error.localizedDescription)
    }
}
