import UIKit

final class ClubCell: UITableViewCell {
    private let clubIconImageView = UIImageView()
    private let nameLabel = UILabel()
    private let categoryLabel = UILabel()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        configureViews()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        configureViews()
    }

    func configure(with club: PersistentClub) {
        nameLabel.text = club.name
        categoryLabel.text = club.category
        clubIconImageView.image =
            UIImage(systemName: club.iconName) ?? UIImage(systemName: "person.3.fill")
        accessibilityLabel = "\(club.name), \(club.category)"
    }

    private func configureViews() {
        clubIconImageView.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        categoryLabel.translatesAutoresizingMaskIntoConstraints = false

        clubIconImageView.contentMode = .scaleAspectFit
        clubIconImageView.tintColor = .systemBlue
        nameLabel.font = .preferredFont(forTextStyle: .headline)
        nameLabel.adjustsFontForContentSizeCategory = true
        categoryLabel.font = .preferredFont(forTextStyle: .subheadline)
        categoryLabel.adjustsFontForContentSizeCategory = true
        categoryLabel.textColor = .secondaryLabel

        contentView.addSubview(clubIconImageView)
        contentView.addSubview(nameLabel)
        contentView.addSubview(categoryLabel)

        NSLayoutConstraint.activate([
            clubIconImageView.leadingAnchor.constraint(
                equalTo: contentView.leadingAnchor,
                constant: 16
            ),
            clubIconImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            clubIconImageView.widthAnchor.constraint(equalToConstant: 36),
            clubIconImageView.heightAnchor.constraint(equalToConstant: 36),

            nameLabel.leadingAnchor.constraint(
                equalTo: clubIconImageView.trailingAnchor,
                constant: 16
            ),
            nameLabel.trailingAnchor.constraint(
                equalTo: contentView.trailingAnchor,
                constant: -16
            ),
            nameLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 12),

            categoryLabel.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
            categoryLabel.trailingAnchor.constraint(equalTo: nameLabel.trailingAnchor),
            categoryLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 4),
            categoryLabel.bottomAnchor.constraint(
                equalTo: contentView.bottomAnchor,
                constant: -12
            )
        ])
    }
}
