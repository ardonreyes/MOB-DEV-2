import Foundation

/// Transfer object whose property names match the published clubs JSON.
struct ClubDTO: Codable, Equatable {
    let name: String
    let category: String
    let iconName: String
}
