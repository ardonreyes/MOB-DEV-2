import Foundation

enum ClubServiceError: LocalizedError {
    case invalidEndpoint
    case invalidResponse
    case unsuccessfulStatusCode(Int)
    case missingData

    var errorDescription: String? {
        switch self {
        case .invalidEndpoint:
            return "The clubs endpoint is not a valid URL."
        case .invalidResponse:
            return "The server returned an invalid response."
        case .unsuccessfulStatusCode(let statusCode):
            return "The server returned HTTP status code \(statusCode)."
        case .missingData:
            return "The server returned no club data."
        }
    }
}

final class ClubService {
    /// Publish CampusCompanion/clubs.json to this repository's main branch.
    static let publishedJSONURL =
        "https://raw.githubusercontent.com/ardonreyes/MOB-DEV-2/main/CampusCompanion/clubs.json"

    func fetchClubs(completion: @escaping (Result<[ClubDTO], Error>) -> Void) {
        guard let url = URL(string: Self.publishedJSONURL) else {
            completion(.failure(ClubServiceError.invalidEndpoint))
            return
        }

        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error {
                print("Club network error: \(error.localizedDescription)")
                completion(.failure(error))
                return
            }

            guard let httpResponse = response as? HTTPURLResponse else {
                print("Club sync failed: invalid HTTP response.")
                completion(.failure(ClubServiceError.invalidResponse))
                return
            }

            guard (200...299).contains(httpResponse.statusCode) else {
                print("Club sync failed with HTTP \(httpResponse.statusCode).")
                completion(.failure(
                    ClubServiceError.unsuccessfulStatusCode(httpResponse.statusCode)
                ))
                return
            }

            guard let data else {
                print("Club sync failed: the response contained no data.")
                completion(.failure(ClubServiceError.missingData))
                return
            }

            do {
                let clubs = try JSONDecoder().decode([ClubDTO].self, from: data)
                completion(.success(clubs))
            } catch {
                print("Club JSON decoding error: \(error.localizedDescription)")
                completion(.failure(error))
            }
        }

        task.resume()
    }
}
