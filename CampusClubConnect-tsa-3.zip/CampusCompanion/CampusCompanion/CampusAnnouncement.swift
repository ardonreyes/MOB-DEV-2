import Foundation

struct CampusAnnouncement {
    let title: String
    let date: String
    let category: String
    let location: String
    let priority: String
    let priorityLevel: String
    let postedBy: String
}

extension CampusAnnouncement {
    static let sampleAnnouncements: [CampusAnnouncement] = [
        CampusAnnouncement(
            title: "Enrollment Period Extended",
            date: "August 3, 2026",
            category: "Registrar",
            location: "Registrar's Office",
            priority: "Urgent",
            priorityLevel: "Urgent",
            postedBy: "Registrar's Office"
        ),
        CampusAnnouncement(
            title: "Library Orientation Schedule",
            date: "August 5, 2026",
            category: "Library",
            location: "Main Library",
            priority: "Normal",
            priorityLevel: "Normal",
            postedBy: "University Library"
        ),
        CampusAnnouncement(
            title: "Campus Wi-Fi Maintenance",
            date: "August 8, 2026",
            category: "IT Services",
            location: "All Campus Buildings",
            priority: "Normal",
            priorityLevel: "Normal",
            postedBy: "IT Services"
        ),
        CampusAnnouncement(
            title: "Student Organization Fair",
            date: "August 12, 2026",
            category: "Student Affairs",
            location: "Student Plaza",
            priority: "Normal",
            priorityLevel: "Normal",
            postedBy: "Student Affairs Office"
        ),
        CampusAnnouncement(
            title: "Scholarship Application Deadline",
            date: "August 15, 2026",
            category: "Financial Aid",
            location: "Financial Aid Office",
            priority: "Urgent",
            priorityLevel: "Urgent",
            postedBy: "Financial Aid Office"
        ),
        CampusAnnouncement(
            title: "Intramurals Registration Opens",
            date: "August 18, 2026",
            category: "Athletics",
            location: "Campus Gym",
            priority: "Normal",
            priorityLevel: "Normal",
            postedBy: "Athletics Office"
        )
    ]
}
