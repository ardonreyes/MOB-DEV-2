import Foundation

struct AnnouncementDTO: Codable {
    let title: String
    let date: String
    let category: String
    let location: String
    let priorityLevel: String

    private enum CodingKeys: String, CodingKey {
        case id
        case name
        case title
        case date
        case category
        case location
        case priorityLevel
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)

        let identifier = try container.decodeIfPresent(String.self, forKey: .id) ?? "?"
        let serverName = try container.decodeIfPresent(String.self, forKey: .name)

        title = try container.decodeIfPresent(String.self, forKey: .title)
            ?? serverName
            ?? "Untitled Announcement"
        date = try container.decodeIfPresent(String.self, forKey: .date)
            ?? "Remote object \(identifier)"
        category = try container.decodeIfPresent(String.self, forKey: .category)
            ?? "Campus API"
        location = try container.decodeIfPresent(String.self, forKey: .location)
            ?? "Online"
        priorityLevel = try container.decodeIfPresent(String.self, forKey: .priorityLevel)
            ?? "Normal"
    }

    init(
        title: String,
        date: String,
        category: String,
        location: String,
        priorityLevel: String
    ) {
        self.title = title
        self.date = date
        self.category = category
        self.location = location
        self.priorityLevel = priorityLevel
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(title, forKey: .title)
        try container.encode(date, forKey: .date)
        try container.encode(category, forKey: .category)
        try container.encode(location, forKey: .location)
        try container.encode(priorityLevel, forKey: .priorityLevel)
    }
}
