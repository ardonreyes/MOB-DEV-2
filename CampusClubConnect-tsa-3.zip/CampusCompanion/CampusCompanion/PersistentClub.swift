import CoreData

@objc(PersistentClub)
final class PersistentClub: NSManagedObject {
    @NSManaged var name: String
    @NSManaged var category: String
    @NSManaged var iconName: String

    @nonobjc class func fetchRequest() -> NSFetchRequest<PersistentClub> {
        NSFetchRequest<PersistentClub>(entityName: "Club")
    }
}
