import UIKit
import CoreData

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    lazy var persistentContainer: NSPersistentContainer = {
        let model = NSManagedObjectModel()

        func makeEntity(
            name: String,
            managedObjectClass: NSManagedObject.Type,
            attributes: [(name: String, defaultValue: String)]
        ) -> NSEntityDescription {
            let entity = NSEntityDescription()
            entity.name = name
            entity.managedObjectClassName = String(describing: managedObjectClass)

            entity.properties = attributes.map { definition in
                let attribute = NSAttributeDescription()
                attribute.name = definition.name
                attribute.attributeType = .stringAttributeType
                attribute.isOptional = false
                attribute.defaultValue = definition.defaultValue
                return attribute
            }
            return entity
        }

        let clubEntity = makeEntity(
            name: "Club",
            managedObjectClass: PersistentClub.self,
            attributes: [
                ("name", ""),
                ("category", ""),
                ("iconName", "person.3.fill")
            ]
        )

        // Retain the earlier announcement entity so existing project features remain compatible.
        let announcementEntity = makeEntity(
            name: "CampusAnnouncement",
            managedObjectClass: PersistentAnnouncement.self,
            attributes: [
                ("title", ""),
                ("date", ""),
                ("category", ""),
                ("location", ""),
                ("priority", "Normal"),
                ("priorityLevel", "Normal"),
                ("postedBy", "")
            ]
        )

        model.entities = [clubEntity, announcementEntity]

        // A dedicated store avoids mixing the MP3 club schema with earlier laboratory data.
        let container = NSPersistentContainer(
            name: "CampusClubConnect",
            managedObjectModel: model
        )
        let storeDescription = container.persistentStoreDescriptions.first
        storeDescription?.shouldMigrateStoreAutomatically = true
        storeDescription?.shouldInferMappingModelAutomatically = true

        container.loadPersistentStores { _, error in
            if let error {
                fatalError("Unresolved Core Data error: \(error.localizedDescription)")
            }
        }
        return container
    }()

    func saveContext() {
        let context = persistentContainer.viewContext
        guard context.hasChanges else { return }

        do {
            try context.save()
        } catch {
            print("Could not save Core Data: \(error.localizedDescription)")
        }
    }

    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        _ = persistentContainer
        return true
    }

    func application(
        _ application: UIApplication,
        configurationForConnecting connectingSceneSession: UISceneSession,
        options: UIScene.ConnectionOptions
    ) -> UISceneConfiguration {
        UISceneConfiguration(
            name: "Default Configuration",
            sessionRole: connectingSceneSession.role
        )
    }

    func application(
        _ application: UIApplication,
        didDiscardSceneSessions sceneSessions: Set<UISceneSession>
    ) { }
}
