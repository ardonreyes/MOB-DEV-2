import UIKit

final class AnnouncementCell: UITableViewCell {
    private let categoryIconImageView = UIImageView()
    private let titleLabel = UILabel()
    private let dateLabel = UILabel()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupViews()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupViews()
    }

    func configure(with announcement: CampusAnnouncement) {
        titleLabel.text = announcement.title
        dateLabel.text = [
            announcement.category,
            announcement.date,
            announcement.location,
            "Priority: " + announcement.priorityLevel
        ].joined(separator: " • ")

        let isUrgent = announcement.priorityLevel.caseInsensitiveCompare("Urgent") == .orderedSame
        categoryIconImageView.image = UIImage(
            systemName: isUrgent
                ? "exclamationmark.triangle.fill"
                : "megaphone.fill"
        )
        categoryIconImageView.tintColor = isUrgent ? .systemRed : .systemBlue
        titleLabel.textColor = isUrgent ? .systemRed : .label
    }

    private func setupViews() {
        categoryIconImageView.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        dateLabel.translatesAutoresizingMaskIntoConstraints = false

        titleLabel.font = .preferredFont(forTextStyle: .headline)
        dateLabel.font = .preferredFont(forTextStyle: .subheadline)
        dateLabel.textColor = .secondaryLabel
        titleLabel.numberOfLines = 0
        dateLabel.numberOfLines = 0

        contentView.addSubview(categoryIconImageView)
        contentView.addSubview(titleLabel)
        contentView.addSubview(dateLabel)

        NSLayoutConstraint.activate([
            categoryIconImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            categoryIconImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            categoryIconImageView.widthAnchor.constraint(equalToConstant: 32),
            categoryIconImageView.heightAnchor.constraint(equalToConstant: 32),

            titleLabel.leadingAnchor.constraint(equalTo: categoryIconImageView.trailingAnchor, constant: 16),
            titleLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            titleLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10),

            dateLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor),
            dateLabel.trailingAnchor.constraint(equalTo: titleLabel.trailingAnchor),
            dateLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 4),
            dateLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -10)
        ])
    }
}
