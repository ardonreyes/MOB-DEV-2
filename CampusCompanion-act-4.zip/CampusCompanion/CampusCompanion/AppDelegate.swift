import UIKit
import CoreData

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    lazy var persistentContainer: NSPersistentContainer = {
        let model = NSManagedObjectModel()
        let entity = NSEntityDescription()
        entity.name = "CampusAnnouncement"
        entity.managedObjectClassName = String(describing: PersistentAnnouncement.self)

        let attributes: [(String, NSAttributeType, String)] = [
            ("title", .stringAttributeType, ""),
            ("date", .stringAttributeType, ""),
            ("category", .stringAttributeType, ""),
            ("priority", .stringAttributeType, "Normal"),
            ("postedBy", .stringAttributeType, "")
        ]

        entity.properties = attributes.map { name, type, defaultValue in
            let attribute = NSAttributeDescription()
            attribute.name = name
            attribute.attributeType = type
            attribute.isOptional = false
            attribute.defaultValue = defaultValue
            return attribute
        }

        model.entities = [entity]

        let container = NSPersistentContainer(
            name: "CampusCompanion",
            managedObjectModel: model
        )
        container.loadPersistentStores { _, error in
            if let error {
                fatalError("Unresolved Core Data error: \(error)")
            }
        }
        return container
    }()

    func saveContext() {
        let context = persistentContainer.viewContext
        guard context.hasChanges else {
            return
        }

        try? context.save()
    }

    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        _ = persistentContainer
        return true
    }

    func application(
        _ application: UIApplication,
        configurationForConnecting connectingSceneSession: UISceneSession,
        options: UIScene.ConnectionOptions
    ) -> UISceneConfiguration {
        UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(
        _ application: UIApplication,
        didDiscardSceneSessions sceneSessions: Set<UISceneSession>
    ) { }
}
