import UIKit

private enum DefaultsKey {
    static let studentName = "studentName"
    static let notificationsEnabled = "notificationsEnabled"
    static let selectedRoleIndex = "selectedRoleIndex"
}

class ViewController: UIViewController {
    @IBOutlet weak var eventDatePicker: UIDatePicker!
    @IBOutlet weak var guestStepper: UIStepper!
    @IBOutlet weak var roleSegmentedControl: UISegmentedControl!
    @IBOutlet weak var notifySwitch: UISwitch!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subtitleLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        titleLabel.text = "Campus Companion"
        subtitleLabel.text = "Your Campus, In You Pocket"
        restorePreferences()
    }

    @IBAction func getStartedTapped(_ sender: UIButton) {
        nameTextField.resignFirstResponder()

        let enteredName = nameTextField.text ?? ""
        UserDefaults.standard.set(enteredName, forKey: DefaultsKey.studentName)
        UserDefaults.standard.set(notifySwitch.isOn, forKey: DefaultsKey.notificationsEnabled)
        UserDefaults.standard.set(
            roleSegmentedControl.selectedSegmentIndex,
            forKey: DefaultsKey.selectedRoleIndex
        )

        performSegue(withIdentifier: "ShowDetailSegue", sender: self)
    }

    @IBAction func resetPreferencesTapped(_ sender: UIButton) {
        UserDefaults.standard.removeObject(forKey: DefaultsKey.studentName)
        UserDefaults.standard.removeObject(forKey: DefaultsKey.notificationsEnabled)
        UserDefaults.standard.removeObject(forKey: DefaultsKey.selectedRoleIndex)

        nameTextField.text = ""
        notifySwitch.isOn = false
        roleSegmentedControl.selectedSegmentIndex = 0
    }

    private func restorePreferences() {
        nameTextField.text = UserDefaults.standard.string(
            forKey: DefaultsKey.studentName
        ) ?? ""
        notifySwitch.isOn = UserDefaults.standard.bool(
            forKey: DefaultsKey.notificationsEnabled
        )
        roleSegmentedControl.selectedSegmentIndex = UserDefaults.standard.integer(
            forKey: DefaultsKey.selectedRoleIndex
        )
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "ShowDetailSegue",
              let destination = segue.destination as? DetailViewController else {
            return
        }

        let enteredName = nameTextField.text ?? ""
        let role = roleSegmentedControl.selectedSegmentIndex == 0 ? "Student" : "Faculty"

        destination.studentName = enteredName.isEmpty ? role : enteredName
        destination.selectedRole = role
        destination.notificationsEnabled = notifySwitch.isOn
        destination.eventDate = eventDatePicker.date
        destination.guestCount = guestStepper.value > 0 ? Int(guestStepper.value) : 1
    }
}
