import CoreData

@objc(PersistentAnnouncement)
final class PersistentAnnouncement: NSManagedObject {
    @NSManaged var title: String
    @NSManaged var date: String
    @NSManaged var category: String
    @NSManaged var priority: String
    @NSManaged var postedBy: String

    @nonobjc class func fetchRequest() -> NSFetchRequest<PersistentAnnouncement> {
        NSFetchRequest<PersistentAnnouncement>(entityName: "CampusAnnouncement")
    }
}
