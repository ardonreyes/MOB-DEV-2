import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var eventDatePicker: UIDatePicker!
    @IBOutlet weak var guestStepper: UIStepper!
    @IBOutlet weak var roleSegmentedControl: UISegmentedControl!
    @IBOutlet weak var notifySwitch: UISwitch!
    @IBOutlet weak var nameTextField: UITextField!
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subtitleLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        titleLabel.text = "Campus Companion"
        subtitleLabel.text = "Your Campus, In You Pocket"
    }

    @IBAction func getStartedTapped(_ sender: UIButton) {
        nameTextField.resignFirstResponder()
        performSegue(withIdentifier: "ShowDetailSegue", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "ShowDetailSegue",
              let destination = segue.destination as? DetailViewController else {
            return
        }
        
        let enteredName = nameTextField.text ?? ""
        let role = roleSegmentedControl.selectedSegmentIndex == 0 ? "Student" : "Faculty"
        
        destination.studentName = enteredName.isEmpty ? role : enteredName
        
        destination.selectedRole = roleSegmentedControl.selectedSegmentIndex == 0
        ? "Student" : "Faculty"
        destination.notificationsEnabled = notifySwitch.isOn
        destination.eventDate = eventDatePicker.date
        destination.guestCount = guestStepper.value > 0 ? Int(guestStepper.value) : 1
    }
}
