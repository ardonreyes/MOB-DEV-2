import Foundation

struct CampusAnnouncement {
    let title: String
    let date: String
    let category: String
    let priority: String
    let postedBy: String
}

extension CampusAnnouncement {
    static let sampleAnnouncements: [CampusAnnouncement] = [
        CampusAnnouncement(
            title: "Enrollment Period Extended",
            date: "August 3, 2026",
            category: "Registrar",
            priority: "Urgent",
            postedBy: "Registrar's Office"
        ),
        CampusAnnouncement(
            title: "Library Orientation Schedule",
            date: "August 5, 2026",
            category: "Library",
            priority: "Normal",
            postedBy: "University Library"
        ),
        CampusAnnouncement(
            title: "Campus Wi-Fi Maintenance",
            date: "August 8, 2026",
            category: "IT Services",
            priority: "Normal",
            postedBy: "IT Services"
        ),
        CampusAnnouncement(
            title: "Student Organization Fair",
            date: "August 12, 2026",
            category: "Student Affairs",
            priority: "Normal",
            postedBy: "Student Affairs Office"
        ),
        CampusAnnouncement(
            title: "Scholarship Application Deadline",
            date: "August 15, 2026",
            category: "Financial Aid",
            priority: "Urgent",
            postedBy: "Financial Aid Office"
        ),
        CampusAnnouncement(
            title: "Intramurals Registration Opens",
            date: "August 18, 2026",
            category: "Athletics",
            priority: "Normal",
            postedBy: "Athletics Office"
        )
    ]
}
