import UIKit

class DetailViewController: UIViewController {
    @IBOutlet weak var messageLabel: UILabel!

    var studentName: String = ""
    var notificationsEnabled: Bool = false
    var selectedRole: String = ""
    var eventDate: Date = Date()
    var guestCount: Int = 1
    var announcement: CampusAnnouncement?

    override func viewDidLoad() {
        super.viewDidLoad()

        messageLabel.textAlignment = .center
        messageLabel.numberOfLines = 0

        if let announcement {
            title = announcement.category
            messageLabel.text = """
            \(announcement.title)
            \(announcement.date)
            Priority: \(announcement.priority)
            Posted by: \(announcement.postedBy)
            """
            return
        }

        title = "Campus Events"

        let notificationStatus = notificationsEnabled ? "on" : "off"
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .none
        let formattedEventDate = dateFormatter.string(from: eventDate)

        messageLabel.text = """
        Welcome, \(studentName)!
        (\(selectedRole))
        Notifications: \(notificationStatus).
        Event date: \(formattedEventDate)
        Guests: \(guestCount)
        """
    }
}
