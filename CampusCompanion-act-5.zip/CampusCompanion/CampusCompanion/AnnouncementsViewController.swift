import UIKit
import CoreData

private enum RemoteEndpoint {
    static let announcements = URL(
        string: "https://api.restful-api.dev/objects"
    )!
}

final class AnnouncementsViewController: UITableViewController {
    private var announcements: [PersistentAnnouncement] = []
    private var selectedAnnouncement: CampusAnnouncement?

    private var context: NSManagedObjectContext {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            fatalError("AppDelegate is unavailable")
        }
        return appDelegate.persistentContainer.viewContext
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Campus Announcements"
        tableView.register(AnnouncementCell.self, forCellReuseIdentifier: "AnnouncementCell")
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 76
        configureActionsMenu()
        seedInitialAnnouncementsIfNeeded()
        loadAnnouncements()
    }

    private func configureActionsMenu() {
        let refreshAction = UIAction(
            title: "Refresh",
            image: UIImage(systemName: "arrow.clockwise")
        ) { [weak self] _ in
            self?.fetchAnnouncementsFromServer()
        }

        let addAction = UIAction(
            title: "Add Announcement",
            image: UIImage(systemName: "plus")
        ) { [weak self] _ in
            self?.showAddAnnouncementAlert()
        }

        let menu = UIMenu(children: [refreshAction, addAction])
        let menuButton = UIBarButtonItem(
            title: nil,
            image: UIImage(systemName: "line.3.horizontal"),
            primaryAction: nil,
            menu: menu
        )
        menuButton.accessibilityLabel = "Announcement actions"
        navigationItem.rightBarButtonItem = menuButton
    }

    @IBAction func refreshTapped(_ sender: UIBarButtonItem) {
        fetchAnnouncementsFromServer()
    }

    private func fetchAnnouncementsFromServer() {
        let task = URLSession.shared.dataTask(with: RemoteEndpoint.announcements) { [weak self] data, response, error in
            if let error {
                print("Network error: \(error.localizedDescription)")
                return
            }

            guard let httpResponse = response as? HTTPURLResponse,
                  (200...299).contains(httpResponse.statusCode) else {
                print("Unexpected server response.")
                return
            }

            guard let data else {
                print("The server response did not contain data.")
                return
            }

            if let rawJSON = String(data: data, encoding: .utf8) {
                print(rawJSON)
            }

            do {
                let decodedAnnouncements = try JSONDecoder().decode(
                    [AnnouncementDTO].self,
                    from: data
                )

                DispatchQueue.main.async {
                    guard let self else {
                        return
                    }
                    self.replaceAnnouncements(with: decodedAnnouncements)
                    self.showNetworkConfirmationAlert(byteCount: data.count)
                }
            } catch {
                print("Decoding error: \(error)")
            }
        }
        task.resume()
    }

    private func replaceAnnouncements(with dtos: [AnnouncementDTO]) {
        let request: NSFetchRequest<PersistentAnnouncement> = PersistentAnnouncement.fetchRequest()
        let existingAnnouncements = (try? context.fetch(request)) ?? []

        for announcement in existingAnnouncements {
            context.delete(announcement)
        }

        for dto in dtos {
            let announcement = PersistentAnnouncement(context: context)
            announcement.title = dto.title
            announcement.date = dto.date
            announcement.category = dto.category
            announcement.location = dto.location
            announcement.priority = dto.priorityLevel
            announcement.postedBy = dto.category
        }

        do {
            try context.save()
            loadAnnouncements()
        } catch {
            context.rollback()
            print("Persistence error: \(error)")
        }
    }

    private func showNetworkConfirmationAlert(byteCount: Int) {
        let alert = UIAlertController(
            title: "Server Reached",
            message: "Received \(byteCount) bytes from the announcements endpoint.",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }

    override func tableView(
        _ tableView: UITableView,
        numberOfRowsInSection section: Int
    ) -> Int {
        announcements.count
    }

    override func tableView(
        _ tableView: UITableView,
        cellForRowAt indexPath: IndexPath
    ) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(
            withIdentifier: "AnnouncementCell",
            for: indexPath
        ) as? AnnouncementCell else {
            return UITableViewCell()
        }

        cell.configure(with: value(for: announcements[indexPath.row]))
        return cell
    }

    override func tableView(
        _ tableView: UITableView,
        didSelectRowAt indexPath: IndexPath
    ) {
        tableView.deselectRow(at: indexPath, animated: true)
        selectedAnnouncement = value(for: announcements[indexPath.row])
        performSegue(
            withIdentifier: "ShowAnnouncementDetailSegue",
            sender: self
        )
    }

    override func tableView(
        _ tableView: UITableView,
        commit editingStyle: UITableViewCell.EditingStyle,
        forRowAt indexPath: IndexPath
    ) {
        guard editingStyle == .delete else {
            return
        }

        let announcement = announcements.remove(at: indexPath.row)
        context.delete(announcement)
        try? context.save()
        tableView.deleteRows(at: [indexPath], with: .automatic)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "ShowAnnouncementDetailSegue",
              let destination = segue.destination as? DetailViewController,
              let selectedAnnouncement else {
            return
        }

        destination.announcement = selectedAnnouncement
    }

    @IBAction func addAnnouncementTapped(_ sender: UIBarButtonItem) {
        showAddAnnouncementAlert()
    }

    private func showAddAnnouncementAlert() {
        let alert = UIAlertController(
            title: "New Announcement",
            message: "Enter a title and category.",
            preferredStyle: .alert
        )
        alert.addTextField { $0.placeholder = "Title" }
        alert.addTextField { $0.placeholder = "Category" }

        let saveAction = UIAlertAction(title: "Save", style: .default) { [weak self, weak alert] _ in
            guard let self,
                  let title = alert?.textFields?[0].text?.trimmingCharacters(in: .whitespacesAndNewlines),
                  !title.isEmpty,
                  let category = alert?.textFields?[1].text?.trimmingCharacters(in: .whitespacesAndNewlines),
                  !category.isEmpty else {
                return
            }

            let announcement = PersistentAnnouncement(context: self.context)
            announcement.title = title
            announcement.category = category
            announcement.location = "Campus"
            announcement.date = DateFormatter.localizedString(
                from: Date(),
                dateStyle: .long,
                timeStyle: .none
            )
            announcement.priority = "Normal"
            announcement.postedBy = category

            try? self.context.save()
            self.loadAnnouncements()
        }

        alert.addAction(saveAction)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }

    private func seedInitialAnnouncementsIfNeeded() {
        let request = PersistentAnnouncement.fetchRequest()
        let existingCount = (try? context.count(for: request)) ?? 0
        guard existingCount == 0 else {
            return
        }

        for sample in CampusAnnouncement.sampleAnnouncements {
            let announcement = PersistentAnnouncement(context: context)
            announcement.title = sample.title
            announcement.date = sample.date
            announcement.category = sample.category
            announcement.location = sample.location
            announcement.priority = sample.priority
            announcement.postedBy = sample.postedBy
        }

        try? context.save()
    }

    private func loadAnnouncements() {
        let request = PersistentAnnouncement.fetchRequest()
        request.sortDescriptors = [
            NSSortDescriptor(key: "date", ascending: true)
        ]
        announcements = (try? context.fetch(request)) ?? []
        tableView.reloadData()
    }

    private func value(for announcement: PersistentAnnouncement) -> CampusAnnouncement {
        CampusAnnouncement(
            title: announcement.title,
            date: announcement.date,
            category: announcement.category,
            location: announcement.location,
            priority: announcement.priority,
            postedBy: announcement.postedBy
        )
    }
}
