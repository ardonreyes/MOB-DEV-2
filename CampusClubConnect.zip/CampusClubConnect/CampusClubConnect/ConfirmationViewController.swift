//
//  ConfirmationViewController.swift
//  CampusClubConnect
//
//  Created by ARDON REYES on 10/3/26.
//

import UIKit

final class ConfirmationViewController: UIViewController {

    // MARK: - IBOutlets (connect in Interface Builder)
    @IBOutlet weak var messageLabel: UILabel!

    // MARK: - Public properties with defaults (Part C)
    var name: String = "Club Member"
    var wantsReminders: Bool = false
    var role: String = "Member"

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Confirmation"

        let remindersText = wantsReminders ? "ON" : "OFF"
        let message = """
            Thanks, \(name)! 
            You've signed up as a \(role). Meeting reminders: \(remindersText)
        """
        messageLabel?.text = message
        messageLabel?.numberOfLines = 0
        messageLabel?.textAlignment = .center
    }
}
