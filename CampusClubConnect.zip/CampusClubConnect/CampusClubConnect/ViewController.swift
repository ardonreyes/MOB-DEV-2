//
//  ViewController.swift
//  CampusClubConnect
//
//  Created by ARDON REYES on 10/3/26.
//

import UIKit

final class WelcomeViewController: UIViewController {

    // MARK: - IBOutlets (connect in Interface Builder after this)
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var reminderSwitch: UISwitch!
    @IBOutlet weak var roleSegmentedControl: UISegmentedControl!

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()

        // Part B: Set navigation title
        self.title = "Campus Club Connect"

        // Part A: Set title in code via IBOutlet (safe in case outlet isn’t wired yet)
        titleLabel?.text = "Campus Club Connect"

        configureDefaults()
    }

    // MARK: - Private
    private func configureDefaults() {
        // Set placeholder if not set in storyboard
        if nameTextField?.placeholder?.isEmpty ?? true {
            nameTextField?.placeholder = "Your name"
        }

        // Ensure 2 segments exist and titles are correct
        if let control = roleSegmentedControl {
            if control.numberOfSegments == 0 {
                control.insertSegment(withTitle: "Member", at: 0, animated: false)
                control.insertSegment(withTitle: "Officer", at: 1, animated: false)
            } else {
                if control.titleForSegment(at: 0)?.isEmpty ?? true {
                    control.setTitle("Member", forSegmentAt: 0)
                }
                if control.titleForSegment(at: 1)?.isEmpty ?? true {
                    control.setTitle("Officer", forSegmentAt: 1)
                }
            }
            control.selectedSegmentIndex = 0
        }
    }

    private func selectedRoleString() -> String {
        let index = roleSegmentedControl?.selectedSegmentIndex ?? 0
        return index == 1 ? "Officer" : "Member"
    }

    // MARK: - IBActions
    @IBAction func joinButtonTapped(_ sender: UIButton) {
        // Part C: Dismiss keyboard before segue
        nameTextField?.resignFirstResponder()

        // Part B: Perform manual segue (must exist in storyboard)
        performSegue(withIdentifier: "ShowConfirmationSegue", sender: self)
    }

    // MARK: - Navigation (Part C)
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "ShowConfirmationSegue",
              let dest = segue.destination as? ConfirmationViewController else {
            return
        }

        // Safely read optional text; default to "Club Member" if empty
        let trimmed = nameTextField?.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let name = (trimmed?.isEmpty == false) ? (trimmed ?? "Club Member") : "Club Member"

        let wantsReminders = reminderSwitch?.isOn ?? false
        let role = selectedRoleString()

        dest.name = name
        dest.wantsReminders = wantsReminders
        dest.role = role
    }
}
