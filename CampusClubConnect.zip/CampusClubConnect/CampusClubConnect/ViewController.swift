import UIKit

final class WelcomeViewController: UIViewController {
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var reminderSwitch: UISwitch!
    @IBOutlet weak var roleSegmentedControl: UISegmentedControl!
    @IBOutlet weak var clubImageView: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Campus Club Connect"
        titleLabel?.text = "Campus Club Connect"
        if let photo = UIImage(named: "Photo on 10-13-26 at 7.16 PM") {
            clubImageView?.image = photo
            clubImageView?.tintColor = nil
        } else {
            clubImageView?.image = UIImage(systemName: "person.3.fill")
            clubImageView?.tintColor = .systemBlue
        }
        clubImageView?.contentMode = .scaleAspectFit

        configureDefaults()
    }

    private func configureDefaults() {
        if nameTextField?.placeholder?.isEmpty ?? true {
            nameTextField?.placeholder = "Your name"
        }

        if let control = roleSegmentedControl {
            if control.numberOfSegments == 0 {
                control.insertSegment(withTitle: "Member", at: 0, animated: false)
                control.insertSegment(withTitle: "Officer", at: 1, animated: false)
            } else {
                if control.titleForSegment(at: 0)?.isEmpty ?? true {
                    control.setTitle("Member", forSegmentAt: 0)
                }
                if control.titleForSegment(at: 1)?.isEmpty ?? true {
                    control.setTitle("Officer", forSegmentAt: 1)
                }
            }
            control.selectedSegmentIndex = 0
        }
    }

    private func selectedRoleString() -> String {
        let index = roleSegmentedControl?.selectedSegmentIndex ?? 0
        return index == 1 ? "Officer" : "Member"
    }

    @IBAction func joinButtonTapped(_ sender: UIButton) {
        nameTextField?.resignFirstResponder()
        performSegue(withIdentifier: "ShowConfirmationSegue", sender: self)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "ShowConfirmationSegue",
              let dest = segue.destination as? ConfirmationViewController else {
            return
        }

        let trimmed = nameTextField?.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let name = (trimmed?.isEmpty == false) ? (trimmed ?? "Club Member") : "Club Member"

        let wantsReminders = reminderSwitch?.isOn ?? false
        let role = selectedRoleString()

        dest.name = name
        dest.wantsReminders = wantsReminders
        dest.role = role
    }
}
