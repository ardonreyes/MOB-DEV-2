import CoreData
import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    /// The shared Core Data stack used by the club directory.
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "CampusClubConnect")
        container.loadPersistentStores { _, error in
            if let error {
                // A missing store would make the directory unusable, so fail early with
                // a useful diagnostic during development instead of silently losing data.
                fatalError("Unable to load the club store: \(error.localizedDescription)")
            }
        }
        container.viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
        container.viewContext.automaticallyMergesChangesFromParent = true
        return container
    }()

    var viewContext: NSManagedObjectContext {
        persistentContainer.viewContext
    }

    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        // Load the store at launch so persistence errors appear before the list is used.
        _ = persistentContainer
        return true
    }

    // MARK: - UISceneSession Lifecycle

    func application(
        _ application: UIApplication,
        configurationForConnecting connectingSceneSession: UISceneSession,
        options: UIScene.ConnectionOptions
    ) -> UISceneConfiguration {
        UISceneConfiguration(
            name: "Default Configuration",
            sessionRole: connectingSceneSession.role
        )
    }
}
