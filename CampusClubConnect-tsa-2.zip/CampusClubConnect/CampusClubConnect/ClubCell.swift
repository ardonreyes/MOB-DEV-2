import UIKit

final class ClubCell: UITableViewCell {

    @IBOutlet private weak var clubIconImageView: UIImageView!
    @IBOutlet private weak var clubNameLabel: UILabel!
    @IBOutlet private weak var categoryLabel: UILabel!

    func configure(with club: Club) {
        clubNameLabel.text = club.name ?? "Unnamed Club"
        categoryLabel.text = club.category ?? "Uncategorized"
        clubIconImageView.image = UIImage(
            systemName: club.iconName ?? "person.3.fill"
        )
        clubIconImageView.tintColor = .systemBlue
        accessoryType = .disclosureIndicator
    }
}
