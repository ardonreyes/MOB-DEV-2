import UIKit

final class WelcomeViewController: UIViewController {

    @IBOutlet private weak var titleLabel: UILabel!
    @IBOutlet private weak var nameTextField: UITextField!
    @IBOutlet private weak var reminderSwitch: UISwitch!
    @IBOutlet private weak var roleSegmentedControl: UISegmentedControl!

    /// Named keys keep the saved-value contract in one place and prevent spelling mistakes.
    private enum DefaultsKey {
        static let studentName = "studentName"
        static let notificationsEnabled = "notificationsEnabled"
        static let selectedRoleIndex = "selectedRoleIndex"
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Campus Club Connect"
        titleLabel.text = "Campus Club Connect"
        restoreWelcomeValues()
    }

    private func restoreWelcomeValues() {
        let defaults = UserDefaults.standard
        nameTextField.text = defaults.string(forKey: DefaultsKey.studentName) ?? ""

        // object(forKey:) distinguishes a first launch from a deliberately saved false value.
        reminderSwitch.isOn = defaults.object(forKey: DefaultsKey.notificationsEnabled) == nil
            ? true
            : defaults.bool(forKey: DefaultsKey.notificationsEnabled)

        let savedIndex = defaults.object(forKey: DefaultsKey.selectedRoleIndex) == nil
            ? 0
            : defaults.integer(forKey: DefaultsKey.selectedRoleIndex)
        roleSegmentedControl.selectedSegmentIndex =
            (0..<roleSegmentedControl.numberOfSegments).contains(savedIndex) ? savedIndex : 0
    }

    private func saveWelcomeValues() {
        let defaults = UserDefaults.standard
        defaults.set(nameTextField.text ?? "", forKey: DefaultsKey.studentName)
        defaults.set(reminderSwitch.isOn, forKey: DefaultsKey.notificationsEnabled)
        defaults.set(
            roleSegmentedControl.selectedSegmentIndex,
            forKey: DefaultsKey.selectedRoleIndex
        )
    }

    private var selectedRole: String {
        roleSegmentedControl.selectedSegmentIndex == 1 ? "Officer" : "Member"
    }

    @IBAction private func joinButtonTapped(_ sender: UIButton) {
        nameTextField.resignFirstResponder()
        saveWelcomeValues()
        performSegue(withIdentifier: "ShowConfirmationSegue", sender: self)
    }

    @IBAction private func browseClubsButtonTapped(_ sender: UIButton) {
        nameTextField.resignFirstResponder()
        saveWelcomeValues()
        performSegue(withIdentifier: "ShowClubListSegue", sender: self)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "ShowConfirmationSegue",
              let destination = segue.destination as? ConfirmationViewController else {
            return
        }

        let trimmedName = nameTextField.text?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        destination.name = trimmedName.isEmpty ? "Club Member" : trimmedName
        destination.wantsReminders = reminderSwitch.isOn
        destination.role = selectedRole
    }
}
