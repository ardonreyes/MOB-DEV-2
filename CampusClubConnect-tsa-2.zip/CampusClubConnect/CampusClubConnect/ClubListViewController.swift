import CoreData
import UIKit

final class ClubListViewController: UITableViewController {

    private enum SegueIdentifier {
        static let showClubDetail = "ShowClubDetailSegue"
    }

    private var clubs: [Club] = []
    private var selectedClub: Club?

    private var context: NSManagedObjectContext {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            preconditionFailure("The application delegate must provide the Core Data context.")
        }
        return appDelegate.viewContext
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Campus Clubs"
        tableView.rowHeight = 76
        tableView.estimatedRowHeight = 76
        tableView.tableFooterView = UIView()
        loadClubs()
    }

    // MARK: - Persistence

    private func loadClubs() {
        let request = NSFetchRequest<Club>(entityName: "Club")
        request.sortDescriptors = [
            NSSortDescriptor(key: "name", ascending: true, selector: #selector(NSString.localizedCaseInsensitiveCompare(_:)))
        ]

        do {
            clubs = try context.fetch(request)
            if clubs.isEmpty {
                try seedInitialClubs()
                clubs = try context.fetch(request)
            }
            tableView.reloadData()
        } catch {
            showError(message: "The clubs could not be loaded. \(error.localizedDescription)")
        }
    }

    /// The empty-store check in loadClubs makes this a seed-once operation.
    private func seedInitialClubs() throws {
        let initialClubs = [
            (name: "Arts Collective", category: "Arts & Culture", icon: "paintpalette.fill"),
            (name: "Campus Coders", category: "Technology", icon: "laptopcomputer"),
            (name: "Green Society", category: "Environment", icon: "leaf.fill"),
            (name: "Robotics Club", category: "Engineering", icon: "gearshape.2.fill")
        ]

        for initialClub in initialClubs {
            let club = Club(context: context)
            club.name = initialClub.name
            club.category = initialClub.category
            club.iconName = initialClub.icon
        }

        // Saving once after all inserts keeps the seed operation atomic.
        try context.save()
    }

    private func addClub(name: String, category: String) {
        let club = Club(context: context)
        club.name = name
        club.category = category
        club.iconName = "person.3.fill"

        do {
            try context.save()
            loadClubs()
        } catch {
            context.rollback()
            showError(message: "The new club could not be saved. \(error.localizedDescription)")
        }
    }

    // MARK: - Actions

    @IBAction private func addClubTapped(_ sender: UIBarButtonItem) {
        let alert = UIAlertController(
            title: "Add Club",
            message: "Enter the new campus club's information.",
            preferredStyle: .alert
        )
        alert.addTextField { textField in
            textField.placeholder = "Club name"
            textField.autocapitalizationType = .words
        }
        alert.addTextField { textField in
            textField.placeholder = "Category"
            textField.autocapitalizationType = .words
        }
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Add", style: .default) { [weak self, weak alert] _ in
            guard let self, let alert else { return }

            let name = alert.textFields?[0].text?
                .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            let category = alert.textFields?[1].text?
                .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""

            guard !name.isEmpty, !category.isEmpty else {
                self.showError(message: "Please enter both a club name and a category.")
                return
            }
            self.addClub(name: name, category: category)
        })
        present(alert, animated: true)
    }

    // MARK: - UITableViewDataSource

    override func tableView(
        _ tableView: UITableView,
        numberOfRowsInSection section: Int
    ) -> Int {
        clubs.count
    }

    override func tableView(
        _ tableView: UITableView,
        cellForRowAt indexPath: IndexPath
    ) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(
            withIdentifier: "ClubCell",
            for: indexPath
        ) as? ClubCell else {
            preconditionFailure("ClubCell must use the ClubCell class and reuse identifier.")
        }

        cell.configure(with: clubs[indexPath.row])
        return cell
    }

    // MARK: - UITableViewDelegate and Navigation

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        selectedClub = clubs[indexPath.row]
        performSegue(withIdentifier: SegueIdentifier.showClubDetail, sender: self)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == SegueIdentifier.showClubDetail,
              let destination = segue.destination as? ConfirmationViewController else {
            return
        }
        destination.club = selectedClub
    }

    private func showError(message: String) {
        let alert = UIAlertController(
            title: "Campus Club Connect",
            message: message,
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
