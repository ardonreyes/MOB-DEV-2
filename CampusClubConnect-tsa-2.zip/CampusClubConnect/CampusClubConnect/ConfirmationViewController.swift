import UIKit

final class ConfirmationViewController: UIViewController {

    @IBOutlet private weak var messageLabel: UILabel!

    var name = "Club Member"
    var wantsReminders = false
    var role = "Member"
    var club: Club?

    override func viewDidLoad() {
        super.viewDidLoad()

        messageLabel.numberOfLines = 0
        messageLabel.textAlignment = .center

        if let club {
            title = club.name ?? "Club Details"
            messageLabel.text = """
                \(club.name ?? "Unnamed Club")

                Category: \(club.category ?? "Uncategorized")
                Icon: \(club.iconName ?? "person.3.fill")

                Tap Back to browse the other campus clubs.
                """
        } else {
            title = "Confirmation"
            let remindersText = wantsReminders ? "ON" : "OFF"
            messageLabel.text = """
                Thanks, \(name)!

                You've signed up as a \(role).
                Meeting reminders: \(remindersText)
                """
        }
    }
}
